import { z } from "zod";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import {
  searchUsers,
  getOrCreateDirectConversation,
  createGroupConversation,
  getUserConversations,
  getConversationMessages,
  getConversationMembers,
  addConversationMember,
  removeConversationMember,
  getUserById,
  getUnreadCount,
  clearUnreadCount,
  getOnlineUsers,
  getUserPresence,
} from "./db";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // User procedures
  user: router({
    search: protectedProcedure
      .input(z.object({ query: z.string().min(1) }))
      .mutation(async ({ input, ctx }) => {
        const results = await searchUsers(input.query, ctx.user.id);
        // Enrich results with presence info
        const enriched = await Promise.all(
          results.map(async (user) => {
            const presence = await getUserPresence(user.id);
            return {
              ...user,
              isOnline: presence?.isOnline ?? false,
            };
          })
        );
        return enriched;
      }),

    getProfile: protectedProcedure
      .input(z.object({ userId: z.number() }))
      .query(async ({ input }) => {
        const user = await getUserById(input.userId);
        if (!user) {
          throw new Error("User not found");
        }
        const presence = await getUserPresence(input.userId);
        return {
          ...user,
          isOnline: presence?.isOnline ?? false,
        };
      }),

    getOnlineUsers: protectedProcedure.query(async () => {
      const presenceRecords = await getOnlineUsers();
      const users = await Promise.all(
        presenceRecords.map(async (p) => {
          const user = await getUserById(p.userId);
          return user
            ? {
                ...user,
                isOnline: true,
              }
            : null;
        })
      );
      return users.filter((u) => u !== null);
    }),
  }),

  // Conversation procedures
  conversation: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      const conversations = await getUserConversations(ctx.user.id);
      // Enrich with member info and unread counts
      const enriched = await Promise.all(
        conversations.map(async (conv) => {
          const members = await getConversationMembers(conv.id);
          const unreadCount = await getUnreadCount(conv.id, ctx.user.id);

          let otherUser = null;
          if (conv.type === "direct" && members.length > 0) {
            otherUser = members.find((m) => m.id !== ctx.user.id);
          }

          return {
            ...conv,
            members,
            otherUser,
            unreadCount,
          };
        })
      );
      return enriched;
    }),

    create: protectedProcedure
      .input(z.object({ userId: z.number() }))
      .mutation(async ({ input, ctx }) => {
        if (input.userId === ctx.user.id) {
          throw new Error("Cannot create conversation with yourself");
        }

        const conversation = await getOrCreateDirectConversation(
          ctx.user.id,
          input.userId
        );

        if (!conversation) {
          throw new Error("Failed to create conversation");
        }

        const members = await getConversationMembers(conversation.id);
        const otherUser = members.find((m) => m.id !== ctx.user.id);

        return {
          ...conversation,
          members,
          otherUser,
          unreadCount: 0,
        };
      }),

    createGroup: protectedProcedure
      .input(
        z.object({
          name: z.string().min(1),
          memberIds: z.array(z.number()),
        })
      )
      .mutation(async ({ input, ctx }) => {
        const conversation = await createGroupConversation(
          input.name,
          ctx.user.id,
          input.memberIds
        );

        if (!conversation) {
          throw new Error("Failed to create group conversation");
        }

        const members = await getConversationMembers(conversation.id);

        return {
          ...conversation,
          members,
          unreadCount: 0,
        };
      }),

    getMessages: protectedProcedure
      .input(
        z.object({
          conversationId: z.number(),
          limit: z.number().default(50),
          offset: z.number().default(0),
        })
      )
      .query(async ({ input, ctx }) => {
        // Verify user is member of conversation
        const members = await getConversationMembers(input.conversationId);
        const isMember = members.some((m) => m.id === ctx.user.id);

        if (!isMember) {
          throw new Error("Not a member of this conversation");
        }

        const messages = await getConversationMessages(
          input.conversationId,
          input.limit,
          input.offset
        );

        // Enrich messages with sender info
        const enriched = await Promise.all(
          messages.map(async (msg) => {
            const sender = await getUserById(msg.senderId);
            return {
              ...msg,
              sender,
            };
          })
        );

        return enriched;
      }),

    getMembers: protectedProcedure
      .input(z.object({ conversationId: z.number() }))
      .query(async ({ input, ctx }) => {
        // Verify user is member
        const members = await getConversationMembers(input.conversationId);
        const isMember = members.some((m) => m.id === ctx.user.id);

        if (!isMember) {
          throw new Error("Not a member of this conversation");
        }

        // Enrich with presence info
        const enriched = await Promise.all(
          members.map(async (member) => {
            const presence = await getUserPresence(member.id);
            return {
              ...member,
              isOnline: presence?.isOnline ?? false,
            };
          })
        );

        return enriched;
      }),

    addMember: protectedProcedure
      .input(z.object({ conversationId: z.number(), userId: z.number() }))
      .mutation(async ({ input, ctx }) => {
        // Verify user is member and conversation is group
        const members = await getConversationMembers(input.conversationId);
        const isMember = members.some((m) => m.id === ctx.user.id);

        if (!isMember) {
          throw new Error("Not a member of this conversation");
        }

        const success = await addConversationMember(
          input.conversationId,
          input.userId
        );

        if (!success) {
          throw new Error("Failed to add member");
        }

        return { success: true };
      }),

    removeMember: protectedProcedure
      .input(z.object({ conversationId: z.number(), userId: z.number() }))
      .mutation(async ({ input, ctx }) => {
        // Verify user is member and can remove (creator or self)
        const members = await getConversationMembers(input.conversationId);
        const isMember = members.some((m) => m.id === ctx.user.id);

        if (!isMember) {
          throw new Error("Not a member of this conversation");
        }

        const success = await removeConversationMember(
          input.conversationId,
          input.userId
        );

        if (!success) {
          throw new Error("Failed to remove member");
        }

        return { success: true };
      }),

    markAsRead: protectedProcedure
      .input(z.object({ conversationId: z.number() }))
      .mutation(async ({ input, ctx }) => {
        const count = await clearUnreadCount(input.conversationId, ctx.user.id);
        return { unreadCount: count };
      }),
  }),
});

export type AppRouter = typeof appRouter;
