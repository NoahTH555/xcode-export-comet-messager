import { eq, and, or, desc, asc } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  InsertUser,
  users,
  userPresence,
  conversations,
  conversationMembers,
  messages,
  unreadMessages,
} from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod", "avatar"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = "admin";
      updateSet.role = "admin";
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db
    .select()
    .from(users)
    .where(eq(users.openId, openId))
    .limit(1);

  return result.length > 0 ? result[0] : undefined;
}

export async function getUserById(userId: number) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db
    .select()
    .from(users)
    .where(eq(users.id, userId))
    .limit(1);

  return result.length > 0 ? result[0] : undefined;
}

export async function searchUsers(query: string, excludeUserId?: number) {
  const db = await getDb();
  if (!db) return [];

  const conditions = [
    or(
      eq(users.name, query),
      eq(users.email, query)
    )
  ];

  if (excludeUserId) {
    conditions.push(eq(users.id, excludeUserId));
  }

  const result = await db
    .select()
    .from(users)
    .where(and(...conditions))
    .limit(20);

  return result;
}

export async function getOrCreateDirectConversation(
  userId1: number,
  userId2: number
) {
  const db = await getDb();
  if (!db) return null;

  // Check if conversation already exists
  const existing = await db
    .selectDistinct()
    .from(conversations)
    .innerJoin(
      conversationMembers,
      eq(conversations.id, conversationMembers.conversationId)
    )
    .where(
      and(
        eq(conversations.type, "direct")
      )
    )
    .limit(1);

  // Filter for conversations with both users
  for (const row of existing) {
    const conv = row.conversations;
    const members = await db
      .select()
      .from(conversationMembers)
      .where(eq(conversationMembers.conversationId, conv.id));
    
    const userIds = members.map(m => m.userId);
    if (userIds.includes(userId1) && userIds.includes(userId2) && userIds.length === 2) {
      return conv;
    }
  }

  const existing2 = await db
    .select()
    .from(conversations)
    .where(eq(conversations.type, "direct"));

  for (const conv of existing2) {
    const members = await db
      .select()
      .from(conversationMembers)
      .where(eq(conversationMembers.conversationId, conv.id));
    
    const userIds = members.map(m => m.userId);
    if (userIds.includes(userId1) && userIds.includes(userId2) && userIds.length === 2) {
      return conv;
    }
  }

  // Create new direct conversation
  const result = await db.insert(conversations).values({
    type: "direct",
    createdBy: userId1,
  });

  const conversationId = Number(result[0].insertId);

  // Add both users as members
  await db.insert(conversationMembers).values([
    { conversationId, userId: userId1 },
    { conversationId, userId: userId2 },
  ]);

  // Initialize unread counts
  await db.insert(unreadMessages).values([
    { conversationId, userId: userId1, unreadCount: 0 },
    { conversationId, userId: userId2, unreadCount: 0 },
  ]);

  const newConversation = await db
    .select()
    .from(conversations)
    .where(eq(conversations.id, conversationId))
    .limit(1);

  return newConversation.length > 0 ? newConversation[0] : null;
}

export async function createGroupConversation(
  name: string,
  createdBy: number,
  memberIds: number[]
) {
  const db = await getDb();
  if (!db) return null;

  const result = await db.insert(conversations).values({
    name,
    type: "group",
    createdBy,
  });

  const conversationId = Number(result[0].insertId);

  // Add all members including creator
  const allMembers = [createdBy, ...memberIds];
  await db.insert(conversationMembers).values(
    allMembers.map((userId) => ({
      conversationId,
      userId,
    }))
  );

  // Initialize unread counts
  await db.insert(unreadMessages).values(
    allMembers.map((userId) => ({
      conversationId,
      userId,
      unreadCount: 0,
    }))
  );

  const newConversation = await db
    .select()
    .from(conversations)
    .where(eq(conversations.id, conversationId))
    .limit(1);

  return newConversation.length > 0 ? newConversation[0] : null;
}

export async function getUserConversations(userId: number) {
  const db = await getDb();
  if (!db) return [];

  const result = await db
    .select()
    .from(conversations)
    .innerJoin(
      conversationMembers,
      eq(conversations.id, conversationMembers.conversationId)
    )
    .where(eq(conversationMembers.userId, userId))
    .orderBy(desc(conversations.updatedAt));

  return result.map((r) => r.conversations);
}

export async function getConversationMessages(
  conversationId: number,
  limit: number = 50,
  offset: number = 0
) {
  const db = await getDb();
  if (!db) return [];

  const result = await db
    .select()
    .from(messages)
    .where(eq(messages.conversationId, conversationId))
    .orderBy(asc(messages.createdAt))
    .limit(limit)
    .offset(offset);

  return result;
}

export async function addMessage(
  conversationId: number,
  senderId: number,
  content: string
) {
  const db = await getDb();
  if (!db) return null;

  const result = await db.insert(messages).values({
    conversationId,
    senderId,
    content,
  });

  const messageId = result[0].insertId;

  const message = await db
    .select()
    .from(messages)
    .where(eq(messages.id, Number(messageId)))
    .limit(1);

  return message.length > 0 ? message[0] : null;
}

export async function getConversationMembers(conversationId: number) {
  const db = await getDb();
  if (!db) return [];

  const result = await db
    .select({
      id: conversationMembers.id,
      userId: conversationMembers.userId,
      conversationId: conversationMembers.conversationId,
      joinedAt: conversationMembers.joinedAt,
      userName: users.name,
      userEmail: users.email,
      userAvatar: users.avatar,
    })
    .from(conversationMembers)
    .innerJoin(users, eq(conversationMembers.userId, users.id))
    .where(eq(conversationMembers.conversationId, conversationId));

  return result as any[]
}

export async function addConversationMember(
  conversationId: number,
  userId: number
) {
  const db = await getDb();
  if (!db) return false;

  try {
    await db.insert(conversationMembers).values({
      conversationId,
      userId,
    });

    // Initialize unread count for new member
    await db.insert(unreadMessages).values({
      conversationId,
      userId,
      unreadCount: 0,
    });

    return true;
  } catch (error) {
    console.error("[Database] Failed to add conversation member:", error);
    return false;
  }
}

export async function removeConversationMember(
  conversationId: number,
  userId: number
) {
  const db = await getDb();
  if (!db) return false;

  try {
    await db
      .delete(conversationMembers)
      .where(
        and(
          eq(conversationMembers.conversationId, conversationId),
          eq(conversationMembers.userId, userId)
        )
      );

    // Remove unread count for removed member
    await db
      .delete(unreadMessages)
      .where(
        and(
          eq(unreadMessages.conversationId, conversationId),
          eq(unreadMessages.userId, userId)
        )
      );

    return true;
  } catch (error) {
    console.error("[Database] Failed to remove conversation member:", error);
    return false;
  }
}

export async function updateUserPresence(
  userId: number,
  isOnline: boolean,
  socketId?: string
) {
  const db = await getDb();
  if (!db) return null;

  try {
    // Check if presence record exists
    const existing = await db
      .select()
      .from(userPresence)
      .where(eq(userPresence.userId, userId))
      .limit(1);

    if (existing.length > 0) {
      await db
        .update(userPresence)
        .set({
          isOnline,
          socketId: socketId || null,
          lastSeenAt: new Date(),
        })
        .where(eq(userPresence.userId, userId));
    } else {
      await db.insert(userPresence).values({
        userId,
        isOnline,
        socketId: socketId || null,
      });
    }

    const updated = await db
      .select()
      .from(userPresence)
      .where(eq(userPresence.userId, userId))
      .limit(1);

    return updated.length > 0 ? updated[0] : null;
  } catch (error) {
    console.error("[Database] Failed to update user presence:", error);
    return null;
  }
}

export async function getUserPresence(userId: number) {
  const db = await getDb();
  if (!db) return null;

  const result = await db
    .select()
    .from(userPresence)
    .where(eq(userPresence.userId, userId))
    .limit(1);

  return result.length > 0 ? result[0] : null;
}

export async function getOnlineUsers() {
  const db = await getDb();
  if (!db) return [];

  const result = await db
    .select()
    .from(userPresence)
    .where(eq(userPresence.isOnline, true));

  return result;
}

export async function getUnreadCount(
  conversationId: number,
  userId: number
) {
  const db = await getDb();
  if (!db) return 0;

  const result = await db
    .select()
    .from(unreadMessages)
    .where(
      and(
        eq(unreadMessages.conversationId, conversationId),
        eq(unreadMessages.userId, userId)
      )
    )
    .limit(1);

  return result.length > 0 ? result[0].unreadCount : 0;
}

export async function updateUnreadCount(
  conversationId: number,
  userId: number,
  count: number
) {
  const db = await getDb();
  if (!db) return null;

  try {
    const newCount = Math.max(0, count);

    await db
      .update(unreadMessages)
      .set({ unreadCount: newCount })
      .where(
        and(
          eq(unreadMessages.conversationId, conversationId),
          eq(unreadMessages.userId, userId)
        )
      );

    return newCount;
  } catch (error) {
    console.error("[Database] Failed to update unread count:", error);
    return null;
  }
}

export async function clearUnreadCount(
  conversationId: number,
  userId: number
) {
  const db = await getDb();
  if (!db) return null;

  try {
    await db
      .update(unreadMessages)
      .set({ unreadCount: 0, lastReadAt: new Date() })
      .where(
        and(
          eq(unreadMessages.conversationId, conversationId),
          eq(unreadMessages.userId, userId)
        )
      );

    return 0;
  } catch (error) {
    console.error("[Database] Failed to clear unread count:", error);
    return null;
  }
}
