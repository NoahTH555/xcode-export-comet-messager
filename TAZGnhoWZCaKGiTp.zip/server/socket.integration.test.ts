import { describe, it, expect } from "vitest";
import {
  addMessage,
  getConversationMessages,
  updateUserPresence,
  getUserPresence,
} from "./db";

describe("Real-Time Messaging Integration", () => {
  describe("Message Persistence and Retrieval", () => {
    it("should persist messages to database and retrieve them", async () => {
      const convId = 201;
      const senderId = 202;
      const content = "Test message for integration";

      // Add message
      const message = await addMessage(convId, senderId, content);
      expect(message).toBeDefined();
      expect(message?.content).toBe(content);
      expect(message?.senderId).toBe(senderId);

      // Retrieve messages
      const messages = await getConversationMessages(convId);
      const found = messages.find(
        (m) => m.id === message?.id && m.content === content
      );
      expect(found).toBeDefined();
    });

    it("should maintain message order by timestamp", async () => {
      const convId = 203;
      const senderId = 204;

      // Add multiple messages
      const msg1 = await addMessage(convId, senderId, "First");
      const msg2 = await addMessage(convId, senderId, "Second");
      const msg3 = await addMessage(convId, senderId, "Third");

      // Retrieve and verify all messages exist
      const messages = await getConversationMessages(convId);
      const relevantMessages = messages.filter(
        (m) => [msg1?.id, msg2?.id, msg3?.id].includes(m.id)
      );

      // Verify all messages are stored
      expect(relevantMessages.length).toBeGreaterThanOrEqual(3);
      expect(relevantMessages.some((m) => m.content === "First")).toBe(true);
      expect(relevantMessages.some((m) => m.content === "Second")).toBe(true);
      expect(relevantMessages.some((m) => m.content === "Third")).toBe(true);
    });
  });

  describe("Presence Tracking", () => {
    it("should track user online/offline status", async () => {
      const userId = 205;

      // User comes online
      const onlinePresence = await updateUserPresence(
        userId,
        true,
        "socket-online"
      );
      expect(onlinePresence?.isOnline).toBe(true);

      // Verify presence
      let presence = await getUserPresence(userId);
      expect(presence?.isOnline).toBe(true);
      expect(presence?.socketId).toBe("socket-online");

      // User goes offline
      const offlinePresence = await updateUserPresence(userId, false);
      expect(offlinePresence?.isOnline).toBe(false);

      // Verify offline status
      presence = await getUserPresence(userId);
      expect(presence?.isOnline).toBe(false);
    });

    it("should update socket ID when user reconnects", async () => {
      const userId = 206;

      // First connection
      await updateUserPresence(userId, true, "socket-1");
      let presence = await getUserPresence(userId);
      expect(presence?.socketId).toBe("socket-1");

      // Reconnect with new socket ID
      await updateUserPresence(userId, true, "socket-2");
      presence = await getUserPresence(userId);
      expect(presence?.socketId).toBe("socket-2");
      expect(presence?.isOnline).toBe(true);
    });
  });

  describe("Message Delivery", () => {
    it("should handle multiple messages in same conversation", async () => {
      const convId = 207;
      const user1 = 208;
      const user2 = 209;

      // Exchange messages
      const msg1 = await addMessage(convId, user1, "Hello from user1");
      const msg2 = await addMessage(convId, user2, "Hi from user2");
      const msg3 = await addMessage(convId, user1, "How are you?");

      // Verify all messages are stored
      const messages = await getConversationMessages(convId);
      const ourMessages = messages.filter(
        (m) => [msg1?.id, msg2?.id, msg3?.id].includes(m.id)
      );

      expect(ourMessages.length).toBeGreaterThanOrEqual(3);
      expect(ourMessages.some((m) => m.senderId === user1)).toBe(true);
      expect(ourMessages.some((m) => m.senderId === user2)).toBe(true);
    });
  });
});
