import { Server as SocketIOServer, Socket } from "socket.io";
import { Server as HTTPServer } from "http";
import {
  addMessage,
  updateUserPresence,
  getConversationMembers,
  updateUnreadCount,
  getUnreadCount,
} from "./db";

interface MessagePayload {
  conversationId: number;
  senderId: number;
  senderName: string;
  content: string;
  timestamp: number;
}

interface PresencePayload {
  userId: number;
  isOnline: boolean;
  userName: string;
}

export function initializeSocketIO(httpServer: HTTPServer) {
  const io = new SocketIOServer(httpServer, {
    cors: {
      origin: process.env.FRONTEND_URL || "*",
      credentials: true,
    },
  });

  // Store user connections: userId -> socketId
  const userConnections = new Map<number, string>();
  // Store socket to user mapping: socketId -> userId
  const socketToUser = new Map<string, number>();

  io.on("connection", (socket: Socket) => {
    console.log(`[Socket] User connected: ${socket.id}`);

    // User joins with their ID
    socket.on("user:join", async (userId: number, userName: string) => {
      userConnections.set(userId, socket.id);
      socketToUser.set(socket.id, userId);

      // Update presence in database
      await updateUserPresence(userId, true, socket.id);

      // Broadcast user online status
      io.emit("presence:update", {
        userId,
        isOnline: true,
        userName,
      } as PresencePayload);

      console.log(`[Socket] User ${userId} joined as ${socket.id}`);
    });

    // Join conversation room
    socket.on("conversation:join", (conversationId: number) => {
      const roomName = `conversation:${conversationId}`;
      socket.join(roomName);
      console.log(`[Socket] ${socket.id} joined room ${roomName}`);
    });

    // Leave conversation room
    socket.on("conversation:leave", (conversationId: number) => {
      const roomName = `conversation:${conversationId}`;
      socket.leave(roomName);
      console.log(`[Socket] ${socket.id} left room ${roomName}`);
    });

    // Handle incoming message
    socket.on(
      "message:send",
      async (payload: {
        conversationId: number;
        senderId: number;
        senderName: string;
        content: string;
      }) => {
        try {
          const { conversationId, senderId, senderName, content } = payload;

          // Save message to database
          const message = await addMessage(conversationId, senderId, content);

          if (message) {
            // Get conversation members
            const members = await getConversationMembers(conversationId);

            // Increment unread count for all members except sender
            for (const member of members) {
              if (member.userId !== senderId) {
                const currentCount = await getUnreadCount(conversationId, member.userId);
                await updateUnreadCount(conversationId, member.userId, currentCount + 1);
              }
            }

            // Broadcast message to all users in the conversation
            const roomName = `conversation:${conversationId}`;
            io.to(roomName).emit("message:receive", {
              conversationId,
              senderId,
              senderName,
              content,
              timestamp: message.createdAt.getTime(),
              messageId: message.id,
            } as MessagePayload & { messageId: number });

            console.log(
              `[Socket] Message sent in conversation ${conversationId}`
            );
          }
        } catch (error) {
          console.error("[Socket] Error sending message:", error);
          socket.emit("message:error", {
            error: "Failed to send message",
          });
        }
      }
    );

    // Handle typing indicator
    socket.on(
      "typing:start",
      (conversationId: number, userName: string) => {
        const roomName = `conversation:${conversationId}`;
        socket.to(roomName).emit("typing:indicator", {
          userName,
          isTyping: true,
        });
      }
    );

    socket.on(
      "typing:stop",
      (conversationId: number, userName: string) => {
        const roomName = `conversation:${conversationId}`;
        socket.to(roomName).emit("typing:indicator", {
          userName,
          isTyping: false,
        });
      }
    );

    // Handle disconnect
    socket.on("disconnect", async () => {
      const userId = socketToUser.get(socket.id);

      if (userId) {
        userConnections.delete(userId);
        socketToUser.delete(socket.id);

        // Update presence in database
        await updateUserPresence(userId, false);

        // Broadcast user offline status
        io.emit("presence:update", {
          userId,
          isOnline: false,
        } as PresencePayload);

        console.log(`[Socket] User ${userId} disconnected`);
      }
    });

    // Handle errors
    socket.on("error", (error) => {
      console.error(`[Socket] Error from ${socket.id}:`, error);
    });
  });

  return io;
}

export function getSocketIO(): SocketIOServer | null {
  // This will be set by the server initialization
  return null;
}
