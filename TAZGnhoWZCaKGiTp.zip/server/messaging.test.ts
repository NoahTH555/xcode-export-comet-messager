import { describe, it, expect } from "vitest";
import {
  getOrCreateDirectConversation,
  createGroupConversation,
  addMessage,
  getConversationMessages,
  getConversationMembers,
  updateUserPresence,
  getUserPresence,
  getUnreadCount,
  updateUnreadCount,
  clearUnreadCount,
} from "./db";

describe("Messaging Features", () => {
  describe("Direct Conversations", () => {
    it("should create a new direct conversation between two users", async () => {
      const conv = await getOrCreateDirectConversation(101, 102);
      expect(conv).toBeDefined();
      expect(conv?.type).toBe("direct");
    });

    it("should return existing direct conversation if it already exists", async () => {
      const conv1 = await getOrCreateDirectConversation(103, 104);
      const conv2 = await getOrCreateDirectConversation(103, 104);
      expect(conv1?.id).toBe(conv2?.id);
    });
  });

  describe("Group Conversations", () => {
    it("should create a new group conversation", async () => {
      const conv = await createGroupConversation("Test Group 1", 105, [106, 107]);
      expect(conv).toBeDefined();
      expect(conv?.type).toBe("group");
      expect(conv?.name).toBe("Test Group 1");
    });

    it("should include creator and all members in group", async () => {
      const conv = await createGroupConversation("Test Group 2", 108, [109, 110]);
      expect(conv).toBeDefined();
      if (conv && conv.id) {
        // Verify conversation was created with correct properties
        expect(conv.type).toBe("group");
        expect(conv.createdBy).toBe(108);
      }
    });
  });

  describe("Messages", () => {
    it("should add a message to a conversation", async () => {
      const conv = await getOrCreateDirectConversation(111, 112);
      if (conv) {
        const message = await addMessage(conv.id, 111, "Hello!");
        expect(message).toBeDefined();
        expect(message?.content).toBe("Hello!");
        expect(message?.senderId).toBe(111);
      }
    });

    it("should retrieve message history", async () => {
      const conv = await getOrCreateDirectConversation(113, 114);
      if (conv) {
        await addMessage(conv.id, 113, "Message 1");
        await addMessage(conv.id, 114, "Message 2");

        const messages = await getConversationMessages(conv.id);
        expect(messages.length).toBeGreaterThanOrEqual(2);
      }
    });
  });

  describe("Presence Tracking", () => {
    it("should update user presence", async () => {
      const presence = await updateUserPresence(115, true, "socket-123");
      expect(presence).toBeDefined();
      expect(presence?.isOnline).toBe(true);
      expect(presence?.socketId).toBe("socket-123");
    });

    it("should retrieve user presence", async () => {
      await updateUserPresence(116, true, "socket-456");
      const presence = await getUserPresence(116);
      expect(presence).toBeDefined();
      expect(presence?.isOnline).toBe(true);
    });

    it("should mark user as offline", async () => {
      await updateUserPresence(117, true, "socket-789");
      await updateUserPresence(117, false);
      const presence = await getUserPresence(117);
      expect(presence?.isOnline).toBe(false);
    });
  });

  describe("Unread Messages", () => {
    it("should track unread message count", async () => {
      const conv = await getOrCreateDirectConversation(118, 119);
      if (conv) {
        const count = await getUnreadCount(conv.id, 119);
        expect(count).toBe(0);
      }
    });

    it("should increment unread count", async () => {
      const conv = await getOrCreateDirectConversation(120, 121);
      if (conv) {
        await updateUnreadCount(conv.id, 121, 1);
        const count = await getUnreadCount(conv.id, 121);
        expect(count).toBe(1);
      }
    });

    it("should clear unread count", async () => {
      const conv = await getOrCreateDirectConversation(122, 123);
      if (conv) {
        await updateUnreadCount(conv.id, 123, 1);
        await clearUnreadCount(conv.id, 123);
        const count = await getUnreadCount(conv.id, 123);
        expect(count).toBe(0);
      }
    });
  });
});
