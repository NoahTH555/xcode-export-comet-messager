# Comet Messaging App - Multi-Platform Build Guide

This guide explains how to build Comet for iOS (IPA), Android (APK), Windows (EXE), macOS (DMG), and Linux.

## Prerequisites

Before building for any platform, ensure you have:

1. **Node.js 18+** and **pnpm**
2. **Git**
3. Platform-specific requirements (see sections below)

## Project Structure

```
comet/
├── client/          # React frontend (Vite)
├── server/          # Express backend + tRPC
├── drizzle/         # Database schema
├── package.json     # Dependencies
└── vite.config.ts   # Build configuration
```

## Building for Web (Current Deployment)

The app is already deployed at: **https://cometapp-jlrtmz6j.manus.space**

To build locally for web:

```bash
cd comet
pnpm install
pnpm build
pnpm start
```

---

## Building for Mobile (iOS & Android)

### Option 1: React Native (Recommended for Native Apps)

To convert Comet to native mobile apps, you'll need to use **React Native** or **Expo**:

#### Using Expo (Easiest)

```bash
# Install Expo CLI
npm install -g expo-cli

# Create a new Expo project from Comet
expo init comet-mobile --template

# Copy relevant code from client/src to the Expo project
# Adapt Socket.io client for React Native
# Use Expo's built-in APIs for notifications, camera, etc.

# Build for iOS
expo build:ios

# Build for Android
expo build:android
```

#### Using React Native CLI

```bash
# Install React Native CLI
npm install -g react-native-cli

# Create new React Native project
npx react-native init CometMobile

# Install Socket.io for React Native
npm install socket.io-client

# Copy adapted components from client/src
# Build for iOS
cd ios
pod install
cd ..
npx react-native run-ios

# Build for Android
npx react-native run-android
```

### iOS (IPA)

**Requirements:**
- macOS with Xcode 14+
- Apple Developer Account
- CocoaPods

**Steps:**

```bash
# Using Expo (simplest)
expo build:ios --release-channel production

# Or using Xcode directly
cd ios
pod install
cd ..
xcode-select --install
open ios/CometApp.xcworkspace
# In Xcode: Product → Archive → Distribute App
```

**Output:** `.ipa` file ready for App Store or TestFlight

### Android (APK/AAB)

**Requirements:**
- Android Studio
- JDK 11+
- Android SDK

**Steps:**

```bash
# Using Expo (simplest)
expo build:android --release-channel production

# Or using Android Studio
cd android
./gradlew bundleRelease  # Creates AAB for Play Store
./gradlew assembleRelease  # Creates APK
```

**Output:** `.apk` or `.aab` file ready for Google Play Store

---

## Building for Desktop (Windows, macOS, Linux)

### Option 1: Electron (Recommended)

Electron allows you to package the web app as a native desktop application.

#### Setup Electron

```bash
# Install Electron
npm install electron --save-dev

# Install electron-builder for packaging
npm install electron-builder --save-dev
```

#### Create electron/main.ts

```typescript
import { app, BrowserWindow } from 'electron';
import path from 'path';

let mainWindow: BrowserWindow;

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1200,
    height: 800,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      nodeIntegration: false,
      contextIsolation: true,
    },
  });

  // Load the app
  const isDev = process.env.NODE_ENV === 'development';
  const url = isDev
    ? 'http://localhost:5173' // Vite dev server
    : `file://${path.join(__dirname, '../dist/index.html')}`;
  
  mainWindow.loadURL(url);
}

app.on('ready', createWindow);
app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
```

#### Update package.json

```json
{
  "main": "dist/electron/main.js",
  "homepage": "./",
  "build": {
    "appId": "com.comet.messaging",
    "productName": "Comet",
    "files": [
      "dist/**/*",
      "node_modules/**/*"
    ],
    "directories": {
      "buildResources": "assets"
    },
    "win": {
      "target": ["nsis", "portable"]
    },
    "nsis": {
      "oneClick": false,
      "allowToChangeInstallationDirectory": true
    },
    "mac": {
      "target": ["dmg", "zip"]
    },
    "linux": {
      "target": ["AppImage", "deb"]
    }
  }
}
```

#### Build Commands

```bash
# Build web assets
pnpm build

# Build for Windows (EXE)
electron-builder --win

# Build for macOS (DMG)
electron-builder --mac

# Build for Linux (AppImage, DEB)
electron-builder --linux

# Build for all platforms
electron-builder -mwl
```

**Output:**
- Windows: `.exe` installer and portable `.exe`
- macOS: `.dmg` installer
- Linux: `.AppImage` and `.deb` packages

### Option 2: Tauri (Lightweight Alternative)

Tauri is lighter than Electron and uses system WebView.

```bash
# Install Tauri CLI
npm install -D tauri

# Initialize Tauri project
npm run tauri init

# Build
npm run tauri build
```

---

## Building for Web (Self-Hosted)

To run Comet on your own server:

```bash
# Build the project
pnpm build

# Deploy to your server
# The dist/ folder contains the built app
# Copy to your web server (nginx, Apache, etc.)

# Or use Docker
docker build -t comet .
docker run -p 3000:3000 comet
```

### Docker Setup

Create `Dockerfile`:

```dockerfile
FROM node:18-alpine

WORKDIR /app

COPY package.json pnpm-lock.yaml ./
RUN npm install -g pnpm && pnpm install

COPY . .

RUN pnpm build

EXPOSE 3000

CMD ["pnpm", "start"]
```

---

## Important Notes for Multi-Platform Development

### 1. Socket.io Compatibility

- **Web/Desktop:** Full Socket.io support ✅
- **Mobile:** Requires `socket.io-client` for React Native
  ```bash
  npm install socket.io-client
  ```

### 2. Environment Variables

Create `.env.local` for development:

```env
VITE_APP_ID=your_manus_app_id
VITE_OAUTH_PORTAL_URL=https://api.manus.im
VITE_FRONTEND_FORGE_API_URL=your_api_url
VITE_FRONTEND_FORGE_API_KEY=your_api_key
```

### 3. Backend Deployment

The backend server must be deployed separately:

```bash
# Build backend
pnpm build

# Deploy to your server (Heroku, Railway, Render, etc.)
# Or use Docker
```

### 4. Database

- **Development:** SQLite (included)
- **Production:** MySQL/PostgreSQL recommended
  - Update `DATABASE_URL` in environment variables
  - Run migrations: `pnpm db:push`

### 5. Code Signing (for App Stores)

- **iOS:** Requires Apple Developer Certificate
- **Android:** Requires signing key
- **Windows:** Optional code signing certificate
- **macOS:** Requires Apple Developer Certificate

---

## Distribution Channels

| Platform | Channel | Requirements |
|----------|---------|--------------|
| iOS | App Store | Apple Developer Account, $99/year |
| Android | Google Play Store | Google Play Developer Account, $25 one-time |
| Windows | Microsoft Store | Microsoft Developer Account |
| macOS | App Store | Apple Developer Account |
| Linux | Snapcraft, Flathub | Free |
| Web | Your domain | Hosting + SSL certificate |

---

## Quick Start Commands

```bash
# Install dependencies
pnpm install

# Development
pnpm dev

# Build for web
pnpm build

# Test
pnpm test

# Type check
pnpm check

# Format code
pnpm format

# Build for Electron (Windows/Mac/Linux)
electron-builder -mwl

# Build for mobile (requires Expo/React Native setup)
expo build:ios
expo build:android
```

---

## Troubleshooting

### Socket.io Connection Issues
- Ensure backend is running and accessible
- Check CORS settings in server configuration
- Verify WebSocket support on your hosting

### Build Failures
- Clear `node_modules` and reinstall: `rm -rf node_modules && pnpm install`
- Clear build cache: `rm -rf dist`
- Check Node.js version: `node --version` (should be 18+)

### Mobile-Specific Issues
- React Native requires native build tools
- iOS builds only work on macOS
- Android requires Android SDK and emulator/device

---

## Next Steps

1. **Choose your target platform** (Mobile, Desktop, Web)
2. **Install platform-specific tools** (Xcode, Android Studio, Electron, etc.)
3. **Follow the corresponding build section** above
4. **Test thoroughly** on target devices/platforms
5. **Submit to app stores** or self-host

For detailed platform-specific documentation, refer to:
- [Electron Documentation](https://www.electronjs.org/docs)
- [React Native Documentation](https://reactnative.dev/docs/getting-started)
- [Expo Documentation](https://docs.expo.dev/)
- [Tauri Documentation](https://tauri.app/docs/)

---

## Support

For issues or questions:
1. Check the troubleshooting section above
2. Review platform-specific documentation
3. Check the project's GitHub issues
4. Contact the development team

Happy building! 🚀
