import { useState, useEffect } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { X, Search, Loader2 } from "lucide-react";

interface UserSearchModalProps {
  onClose: () => void;
}

export default function UserSearchModal({ onClose }: UserSearchModalProps) {
  const { user } = useAuth();
  const [searchQuery, setSearchQuery] = useState("");
  const [results, setResults] = useState<any[]>([]);

  const searchMutation = trpc.user.search.useMutation();
  const createConversationMutation =
    trpc.conversation.create.useMutation();

  useEffect(() => {
    if (!searchQuery.trim()) {
      setResults([]);
      return;
    }

    const timer = setTimeout(() => {
      searchMutation.mutate(
        { query: searchQuery },
        {
          onSuccess: (data) => {
            setResults(data);
          },
        }
      );
    }, 300);

    return () => clearTimeout(timer);
  }, [searchQuery]);

  const handleStartChat = (userId: number) => {
    createConversationMutation.mutate(
      { userId },
      {
        onSuccess: () => {
          onClose();
          setSearchQuery("");
        },
      }
    );
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 p-4">
      <div className="bg-black border-2 border-neon-cyan w-full max-w-md rounded-sm card-neon">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b-2 border-neon-cyan">
          <h2 className="text-lg font-bold text-neon-cyan">Search Users</h2>
          <button
            onClick={onClose}
            className="p-1 hover:bg-gray-800 transition-colors"
          >
            <X size={20} className="text-neon-pink" />
          </button>
        </div>

        {/* Search Input */}
        <div className="p-4 border-b-2 border-neon-cyan">
          <div className="relative">
            <Search
              size={16}
              className="absolute left-3 top-3 text-neon-cyan"
            />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by name or email..."
              className="input-neon pl-10"
              autoFocus
            />
          </div>
        </div>

        {/* Results */}
        <div className="max-h-96 overflow-y-auto">
          {searchMutation.isPending ? (
            <div className="p-8 flex items-center justify-center">
              <Loader2 className="w-6 h-6 animate-spin text-neon-cyan" />
            </div>
          ) : results.length === 0 && searchQuery ? (
            <div className="p-4 text-center text-muted-foreground">
              <p>No users found</p>
            </div>
          ) : results.length === 0 ? (
            <div className="p-4 text-center text-muted-foreground">
              <p>Start typing to search for users</p>
            </div>
          ) : (
            <div className="divide-y divide-gray-800">
              {results.map((result) => (
                <div
                  key={result.id}
                  className="p-4 hover:bg-gray-900 transition-colors flex items-center justify-between"
                >
                  <div className="flex-1">
                    <p className="font-bold text-foreground">{result.name}</p>
                    <p className="text-sm text-muted-foreground">
                      {result.email}
                    </p>
                    <div className="flex items-center gap-2 mt-1">
                      <div
                        className={
                          result.isOnline
                            ? "presence-online"
                            : "presence-offline"
                        }
                      ></div>
                      <span className="text-xs text-muted-foreground">
                        {result.isOnline ? "Online" : "Offline"}
                      </span>
                    </div>
                  </div>
                  <button
                    onClick={() => handleStartChat(result.id)}
                    disabled={createConversationMutation.isPending}
                    className="btn-neon-cyan py-2 px-4 text-sm ml-2"
                  >
                    Chat
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
