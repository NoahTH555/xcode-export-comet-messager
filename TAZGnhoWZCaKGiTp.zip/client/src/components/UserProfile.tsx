import { useAuth } from "@/_core/hooks/useAuth";
import { useSocket } from "@/contexts/SocketContext";
import { X } from "lucide-react";

interface UserProfileProps {
  onClose: () => void;
}

export default function UserProfile({ onClose }: UserProfileProps) {
  const { user } = useAuth();
  const { connected } = useSocket();

  if (!user) {
    return null;
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 p-4">
      <div className="bg-black border-2 border-neon-cyan w-full max-w-md rounded-sm card-neon">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b-2 border-neon-cyan">
          <h2 className="text-lg font-bold text-neon-cyan">Profile</h2>
          <button
            onClick={onClose}
            className="p-1 hover:bg-gray-800 transition-colors"
          >
            <X size={20} className="text-neon-pink" />
          </button>
        </div>

        {/* Profile Content */}
        <div className="p-6 space-y-6">
          {/* Avatar */}
          <div className="flex justify-center">
            <div className="w-24 h-24 rounded-sm bg-gradient-to-br from-neon-pink to-neon-cyan flex items-center justify-center border-2 border-neon-cyan">
              <span className="text-3xl font-bold text-black">
                {user.name?.charAt(0).toUpperCase() || "U"}
              </span>
            </div>
          </div>

          {/* User Info */}
          <div className="space-y-4">
            <div>
              <p className="text-xs text-muted-foreground mb-1">Name</p>
              <p className="text-lg font-bold text-neon-cyan">{user.name}</p>
            </div>

            <div>
              <p className="text-xs text-muted-foreground mb-1">Email</p>
              <p className="text-sm text-foreground">{user.email}</p>
            </div>

            <div>
              <p className="text-xs text-muted-foreground mb-1">Status</p>
              <div className="flex items-center gap-2">
                <div
                  className={`w-3 h-3 rounded-full ${
                    connected ? "bg-neon-green" : "bg-red-500"
                  }`}
                ></div>
                <span className="text-sm text-foreground">
                  {connected ? "Online" : "Offline"}
                </span>
              </div>
            </div>

            <div>
              <p className="text-xs text-muted-foreground mb-1">Role</p>
              <p className="text-sm text-neon-pink capitalize font-bold">
                {user.role}
              </p>
            </div>

            <div>
              <p className="text-xs text-muted-foreground mb-1">Member Since</p>
              <p className="text-sm text-foreground">
                {new Date(user.createdAt).toLocaleDateString()}
              </p>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t-2 border-neon-cyan">
          <button
            onClick={onClose}
            className="w-full btn-neon-cyan py-2"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
}
