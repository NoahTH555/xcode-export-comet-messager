import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Search, Plus, LogOut, Menu, X } from "lucide-react";
import UserSearchModal from "./UserSearchModal";
import CreateGroupModal from "./CreateGroupModal";

interface Conversation {
  id: number;
  name: string | null;
  type: "direct" | "group";
  createdBy: number;
  createdAt: Date;
  updatedAt: Date;
  members?: any[];
  otherUser?: any;
  unreadCount?: number;
}

interface ConversationSidebarProps {
  conversations: Conversation[];
  selectedConversationId: number | null;
  onSelectConversation: (id: number) => void;
  isLoading: boolean;
}

export default function ConversationSidebar({
  conversations,
  selectedConversationId,
  onSelectConversation,
  isLoading,
}: ConversationSidebarProps) {
  const { user, logout } = useAuth();
  const [showSearch, setShowSearch] = useState(false);
  const [showCreateGroup, setShowCreateGroup] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");

  const filteredConversations = conversations.filter((conv) => {
    const name = getConversationName(conv).toLowerCase();
    return name.includes(searchQuery.toLowerCase());
  });

  const handleLogout = async () => {
    await logout();
  };

  const getConversationPreview = (conv: Conversation) => {
    if (conv.type === "group") {
      return `${conv.members?.length || 0} members`;
    }
    const isOnline = conv.otherUser?.isOnline;
    return isOnline ? "Online" : "Offline";
  };

  const getConversationName = (conv: Conversation) => {
    if (conv.type === "group") {
      return conv.name || "Group Chat";
    }
    return conv.otherUser?.name || "Unknown User";
  };

  return (
    <>
      {/* Mobile toggle */}
      <button
        onClick={() => setSidebarOpen(!sidebarOpen)}
        className="md:hidden fixed top-4 left-4 z-50 p-2 bg-black border-2 border-neon-cyan text-neon-cyan"
      >
        {sidebarOpen ? <X size={20} /> : <Menu size={20} />}
      </button>

      {/* Sidebar */}
      <div
        className={`${
          sidebarOpen ? "translate-x-0" : "-translate-x-full"
        } md:translate-x-0 transition-transform duration-300 w-full md:w-80 bg-black border-r-2 border-neon-cyan flex flex-col h-screen fixed md:relative z-40`}
      >
        {/* Header */}
        <div className="p-4 border-b-2 border-neon-cyan">
          <h1 className="text-2xl font-bold text-neon-pink mb-4 text-center">
            COMET
          </h1>

          {/* User Info */}
          <div className="flex items-center justify-between mb-4 p-2 bg-gray-900 border border-neon-cyan rounded-sm">
            <div className="flex-1">
              <p className="text-sm text-neon-cyan font-mono">{user?.name}</p>
              <p className="text-xs text-muted-foreground">{user?.email}</p>
            </div>
            <button
              onClick={handleLogout}
              className="p-1 hover:bg-gray-800 transition-colors"
              title="Logout"
            >
              <LogOut size={16} className="text-neon-pink" />
            </button>
          </div>

          {/* Action Buttons */}
          <div className="flex gap-2">
            <button
              onClick={() => setShowSearch(true)}
              className="flex-1 btn-neon-cyan py-2 text-sm"
            >
              <Search size={16} className="mx-auto" />
            </button>
            <button
              onClick={() => setShowCreateGroup(true)}
              className="flex-1 btn-neon py-2 text-sm"
            >
              <Plus size={16} className="mx-auto" />
            </button>
          </div>
        </div>

        {/* Search Filter */}
        <div className="px-2 py-2 border-b border-neon-cyan bg-gray-900">
          <input
            type="text"
            placeholder="Search conversations..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full px-3 py-2 bg-black border border-neon-cyan text-neon-cyan placeholder-gray-500 rounded-sm text-sm focus:outline-none focus:border-neon-pink"
          />
        </div>

        {/* Conversations List */}
        <div className="flex-1 overflow-y-auto">
          {isLoading ? (
            <div className="p-4 text-center text-muted-foreground">
              <p>Loading conversations...</p>
            </div>
          ) : filteredConversations.length === 0 ? (
            <div className="p-4 text-center text-muted-foreground">
              <p>{searchQuery ? "No matches found" : "No conversations yet"}</p>
              <p className="text-xs mt-2">Start a new chat or search for users</p>
            </div>
          ) : (
            <div className="space-y-1 p-2">
              {filteredConversations.map((conv) => (
                <button
                  key={conv.id}
                  onClick={() => {
                    onSelectConversation(conv.id);
                    setSidebarOpen(false);
                  }}
                  className={`w-full text-left p-3 rounded-sm transition-all duration-200 border-l-4 ${
                    selectedConversationId === conv.id
                      ? "bg-gray-900 border-neon-pink text-neon-pink"
                      : "border-transparent hover:bg-gray-900 text-foreground hover:text-neon-cyan"
                  }`}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1 min-w-0">
                      <p className="font-bold text-sm truncate">
                        {getConversationName(conv)}
                      </p>
                      <p className="text-xs text-muted-foreground truncate">
                        {getConversationPreview(conv)}
                      </p>
                    </div>
                    {conv.unreadCount && conv.unreadCount > 0 && (
                      <div className="badge-unread ml-2 flex-shrink-0">
                        {conv.unreadCount > 99 ? "99+" : conv.unreadCount}
                      </div>
                    )}
                  </div>
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t-2 border-neon-cyan text-xs text-muted-foreground text-center">
          <p>Comet v1.0 - Real-time Messaging</p>
        </div>
      </div>

      {/* Modals */}
      {showSearch && (
        <UserSearchModal onClose={() => setShowSearch(false)} />
      )}
      {showCreateGroup && (
        <CreateGroupModal onClose={() => setShowCreateGroup(false)} />
      )}
    </>
  );
}
