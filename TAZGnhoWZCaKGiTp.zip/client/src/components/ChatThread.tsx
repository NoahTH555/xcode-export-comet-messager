import { useEffect, useRef, useState } from "react";
import { useSocket } from "@/contexts/SocketContext";
import { trpc } from "@/lib/trpc";
import { Send, Loader2 } from "lucide-react";

interface Message {
  id: number;
  conversationId: number;
  senderId: number;
  content: string;
  createdAt: Date | string;
  sender?: {
    id: number;
    name: string | null;
    avatar: string | null;
  };
}

interface ChatThreadProps {
  conversationId: number;
  currentUser: {
    id: number;
    name: string | null;
    email: string | null;
  };
}

export default function ChatThread({
  conversationId,
  currentUser,
}: ChatThreadProps) {
  const { socket, sendMessage, onMessage, startTyping, stopTyping } =
    useSocket();
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputValue, setInputValue] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const [typingUsers, setTypingUsers] = useState<Set<string>>(new Set());
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const typingTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  const { data: messageHistory = [], isLoading: messagesLoading } =
    trpc.conversation.getMessages.useQuery({
      conversationId,
      limit: 50,
    });

  const { data: members = [] } = trpc.conversation.getMembers.useQuery({
    conversationId,
  });

  const markAsReadMutation = trpc.conversation.markAsRead.useMutation();

  // Initialize messages from history
  useEffect(() => {
    if (messageHistory && messageHistory.length > 0) {
      setMessages(messageHistory as Message[]);
    }
  }, [messageHistory]);

  // Join conversation room
  useEffect(() => {
    if (socket) {
      socket.emit("user:join", currentUser.id, currentUser.name);
      socket.emit("conversation:join", conversationId);
      // Mark as read
      markAsReadMutation.mutate({ conversationId });
    }

    return () => {
      if (socket) {
        socket.emit("conversation:leave", conversationId);
      }
    };
  }, [socket, conversationId, currentUser.id, currentUser.name]);

  // Listen for incoming messages
  useEffect(() => {
    if (!socket) return;

    const unsubscribe = onMessage((message: any) => {
      if (message.conversationId === conversationId) {
        setMessages((prev) => [...prev, message]);
        setTypingUsers((prev) => {
          const next = new Set(prev);
          next.delete(message.senderName);
          return next;
        });
      }
    });

    return unsubscribe;
  }, [socket, onMessage, conversationId]);

  // Scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSendMessage = () => {
    if (!inputValue.trim() || !socket) return;

    sendMessage(
      conversationId,
      currentUser.id,
      currentUser.name || "Anonymous",
      inputValue
    );

    setInputValue("");
    setIsTyping(false);
    stopTyping(conversationId, currentUser.name || "Anonymous");
  };

  const handleInputChange = (value: string) => {
    setInputValue(value);

    // Emit typing indicator
    if (!isTyping && value.trim()) {
      setIsTyping(true);
      startTyping(conversationId, currentUser.name || "Anonymous");
    }

    // Clear previous timeout
    if (typingTimeoutRef.current) {
      clearTimeout(typingTimeoutRef.current);
    }

    // Set new timeout to stop typing
    typingTimeoutRef.current = setTimeout(() => {
      setIsTyping(false);
      stopTyping(conversationId, currentUser.name || "Anonymous");
    }, 3000);
  };

  const formatTime = (date: Date | string) => {
    const d = typeof date === "string" ? new Date(date) : date;
    return d.toLocaleTimeString([], {
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="p-4 border-b-2 border-neon-cyan bg-gray-900">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-bold text-neon-cyan">
              {members.length > 0
                ? members.length === 2
                  ? members.find((m: any) => m.id !== currentUser.id)?.name ||
                    "Unknown"
                  : `Group (${members.length})`
                : "Loading..."}
            </h2>
            <p className="text-xs text-muted-foreground">
              {members.filter((m: any) => m.isOnline).length || 0} online
            </p>
          </div>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messagesLoading ? (
          <div className="flex items-center justify-center h-full">
            <Loader2 className="w-8 h-8 animate-spin text-neon-cyan" />
          </div>
        ) : messages.length === 0 ? (
          <div className="flex items-center justify-center h-full">
            <p className="text-muted-foreground">No messages yet</p>
          </div>
        ) : (
          messages.map((message: any) => (
            <div
              key={message.id}
              className={`flex ${
                message.senderId === currentUser.id ? "justify-end" : "justify-start"
              }`}
            >
              <div
                className={`message-bubble ${
                  message.senderId === currentUser.id
                    ? "message-sent"
                    : "message-received"
                }`}
              >
                {message.senderId !== currentUser.id && (
                  <p className="text-xs font-bold mb-1">
                    {message.sender?.name || "Unknown"}
                  </p>
                )}
                <p className="break-words">{message.content}</p>
                <p className="text-xs opacity-70 mt-1">
                  {formatTime(message.createdAt)}
                </p>
              </div>
            </div>
          ))
        )}

        {/* Typing indicator */}
        {typingUsers.size > 0 && (
          <div className="flex justify-start">
            <div className="message-received">
              <p className="text-xs font-bold mb-2">
                {Array.from(typingUsers).join(", ")} is typing...
              </p>
              <div className="typing-indicator">
                <div className="typing-dot"></div>
                <div className="typing-dot"></div>
                <div className="typing-dot"></div>
              </div>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Input */}
      <div className="p-4 border-t-2 border-neon-cyan bg-gray-900">
        <div className="flex gap-2">
          <input
            type="text"
            value={inputValue}
            onChange={(e) => handleInputChange(e.target.value)}
            onKeyPress={(e) => {
              if (e.key === "Enter") {
                handleSendMessage();
              }
            }}
            placeholder="Type a message..."
            className="input-neon flex-1"
          />
          <button
            onClick={handleSendMessage}
            disabled={!inputValue.trim()}
            className="btn-neon-cyan p-3 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <Send size={20} />
          </button>
        </div>
      </div>
    </div>
  );
}
