import { useState, useEffect } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { X, Search, Loader2, Check } from "lucide-react";

interface CreateGroupModalProps {
  onClose: () => void;
}

export default function CreateGroupModal({ onClose }: CreateGroupModalProps) {
  const { user } = useAuth();
  const [groupName, setGroupName] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const [searchResults, setSearchResults] = useState<any[]>([]);
  const [selectedMembers, setSelectedMembers] = useState<Set<number>>(
    new Set()
  );

  const searchMutation = trpc.user.search.useMutation();
  const createGroupMutation = trpc.conversation.createGroup.useMutation();

  useEffect(() => {
    if (!searchQuery.trim()) {
      setSearchResults([]);
      return;
    }

    const timer = setTimeout(() => {
      searchMutation.mutate(
        { query: searchQuery },
        {
          onSuccess: (data: any) => {
            setSearchResults(data);
          },
        }
      );
    }, 300);

    return () => clearTimeout(timer);
  }, [searchQuery]);

  const toggleMember = (userId: number) => {
    const newSelected = new Set(selectedMembers);
    if (newSelected.has(userId)) {
      newSelected.delete(userId);
    } else {
      newSelected.add(userId);
    }
    setSelectedMembers(newSelected);
  };

  const handleCreateGroup = () => {
    if (!groupName.trim() || selectedMembers.size === 0) {
      return;
    }

    createGroupMutation.mutate(
      {
        name: groupName,
        memberIds: Array.from(selectedMembers),
      },
      {
        onSuccess: () => {
          onClose();
          setGroupName("");
          setSearchQuery("");
          setSelectedMembers(new Set());
        },
      }
    );
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 p-4">
      <div className="bg-black border-2 border-neon-cyan w-full max-w-md rounded-sm card-neon">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b-2 border-neon-cyan">
          <h2 className="text-lg font-bold text-neon-cyan">Create Group</h2>
          <button
            onClick={onClose}
            className="p-1 hover:bg-gray-800 transition-colors"
          >
            <X size={20} className="text-neon-pink" />
          </button>
        </div>

        {/* Group Name Input */}
        <div className="p-4 border-b-2 border-neon-cyan">
          <label className="block text-sm font-bold text-neon-cyan mb-2">
            Group Name
          </label>
          <input
            type="text"
            value={groupName}
            onChange={(e) => setGroupName(e.target.value)}
            placeholder="Enter group name..."
            className="input-neon w-full"
          />
        </div>

        {/* Search Users */}
        <div className="p-4 border-b-2 border-neon-cyan">
          <label className="block text-sm font-bold text-neon-cyan mb-2">
            Add Members
          </label>
          <div className="relative">
            <Search
              size={16}
              className="absolute left-3 top-3 text-neon-cyan"
            />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search users..."
              className="input-neon pl-10 w-full"
            />
          </div>
        </div>

        {/* Selected Members */}
        {selectedMembers.size > 0 && (
          <div className="p-4 border-b-2 border-neon-cyan">
            <p className="text-sm font-bold text-neon-cyan mb-2">
              Selected ({selectedMembers.size})
            </p>
            <div className="flex flex-wrap gap-2">
              {searchResults
                .filter((r) => selectedMembers.has(r.id))
                .map((member) => (
                  <div
                    key={member.id}
                    className="px-3 py-1 bg-pink-900 border border-neon-pink rounded-sm text-sm text-pink-100 flex items-center gap-2"
                  >
                    {member.name}
                    <button
                      onClick={() => toggleMember(member.id)}
                      className="hover:opacity-70"
                    >
                      <X size={14} />
                    </button>
                  </div>
                ))}
            </div>
          </div>
        )}

        {/* Search Results */}
        <div className="max-h-64 overflow-y-auto">
          {searchMutation.isPending ? (
            <div className="p-8 flex items-center justify-center">
              <Loader2 className="w-6 h-6 animate-spin text-neon-cyan" />
            </div>
          ) : searchResults.length === 0 && searchQuery ? (
            <div className="p-4 text-center text-muted-foreground">
              <p>No users found</p>
            </div>
          ) : searchResults.length === 0 ? (
            <div className="p-4 text-center text-muted-foreground">
              <p>Search for users to add</p>
            </div>
          ) : (
            <div className="divide-y divide-gray-800">
              {searchResults.map((result) => (
                <button
                  key={result.id}
                  onClick={() => toggleMember(result.id)}
                  className="w-full p-4 hover:bg-gray-900 transition-colors flex items-center justify-between text-left"
                >
                  <div className="flex-1">
                    <p className="font-bold text-foreground">{result.name}</p>
                    <p className="text-sm text-muted-foreground">
                      {result.email}
                    </p>
                  </div>
                  {selectedMembers.has(result.id) && (
                    <Check size={20} className="text-neon-green" />
                  )}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Actions */}
        <div className="p-4 border-t-2 border-neon-cyan flex gap-2">
          <button
            onClick={onClose}
            className="flex-1 btn-neon-cyan py-2"
          >
            Cancel
          </button>
          <button
            onClick={handleCreateGroup}
            disabled={
              !groupName.trim() ||
              selectedMembers.size === 0 ||
              createGroupMutation.isPending
            }
            className="flex-1 btn-neon py-2 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {createGroupMutation.isPending ? (
              <Loader2 size={16} className="mx-auto animate-spin" />
            ) : (
              "Create"
            )}
          </button>
        </div>
      </div>
    </div>
  );
}
