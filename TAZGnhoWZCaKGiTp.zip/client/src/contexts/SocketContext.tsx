import React, { createContext, useContext, useEffect, useState } from "react";
import { io, Socket } from "socket.io-client";

interface Message {
  conversationId: number;
  senderId: number;
  senderName: string;
  content: string;
  timestamp: number;
  messageId: number;
}

interface PresenceUpdate {
  userId: number;
  isOnline: boolean;
  userName?: string;
}

interface TypingIndicator {
  userName: string;
  isTyping: boolean;
}

interface SocketContextType {
  socket: Socket | null;
  connected: boolean;
  joinConversation: (conversationId: number) => void;
  leaveConversation: (conversationId: number) => void;
  sendMessage: (
    conversationId: number,
    senderId: number,
    senderName: string,
    content: string
  ) => void;
  startTyping: (conversationId: number, userName: string) => void;
  stopTyping: (conversationId: number, userName: string) => void;
  onMessage: (callback: (message: Message) => void) => void;
  onPresenceUpdate: (callback: (update: PresenceUpdate) => void) => void;
  onTypingIndicator: (callback: (indicator: TypingIndicator) => void) => void;
}

const SocketContext = createContext<SocketContextType | undefined>(undefined);

export function SocketProvider({ children }: { children: React.ReactNode }) {
  const [socket, setSocket] = useState<Socket | null>(null);
  const [connected, setConnected] = useState(false);

  useEffect(() => {
    // Initialize Socket.io connection
    const newSocket = io(window.location.origin, {
      reconnection: true,
      reconnectionDelay: 1000,
      reconnectionDelayMax: 5000,
      reconnectionAttempts: 5,
    });

    newSocket.on("connect", () => {
      console.log("[Socket] Connected to server");
      setConnected(true);
    });

    newSocket.on("disconnect", () => {
      console.log("[Socket] Disconnected from server");
      setConnected(false);
    });

    newSocket.on("error", (error) => {
      console.error("[Socket] Error:", error);
    });

    setSocket(newSocket);

    return () => {
      newSocket.disconnect();
    };
  }, []);

  const joinConversation = (conversationId: number) => {
    if (socket) {
      socket.emit("conversation:join", conversationId);
    }
  };

  const leaveConversation = (conversationId: number) => {
    if (socket) {
      socket.emit("conversation:leave", conversationId);
    }
  };

  const sendMessage = (
    conversationId: number,
    senderId: number,
    senderName: string,
    content: string
  ) => {
    if (socket) {
      socket.emit("message:send", {
        conversationId,
        senderId,
        senderName,
        content,
      });
    }
  };

  const startTyping = (conversationId: number, userName: string) => {
    if (socket) {
      socket.emit("typing:start", conversationId, userName);
    }
  };

  const stopTyping = (conversationId: number, userName: string) => {
    if (socket) {
      socket.emit("typing:stop", conversationId, userName);
    }
  };

  const onMessage = (callback: (message: Message) => void) => {
    if (socket) {
      socket.on("message:receive", callback);
      return () => {
        socket.off("message:receive", callback);
      };
    }
    return () => {};
  };

  const onPresenceUpdate = (callback: (update: PresenceUpdate) => void) => {
    if (socket) {
      socket.on("presence:update", callback);
      return () => {
        socket.off("presence:update", callback);
      };
    }
    return () => {};
  };

  const onTypingIndicator = (callback: (indicator: TypingIndicator) => void) => {
    if (socket) {
      socket.on("typing:indicator", callback);
      return () => {
        socket.off("typing:indicator", callback);
      };
    }
    return () => {};
  };

  return (
    <SocketContext.Provider
      value={{
        socket,
        connected,
        joinConversation,
        leaveConversation,
        sendMessage,
        startTyping,
        stopTyping,
        onMessage,
        onPresenceUpdate,
        onTypingIndicator,
      }}
    >
      {children}
    </SocketContext.Provider>
  );
}

export function useSocket() {
  const context = useContext(SocketContext);
  if (!context) {
    throw new Error("useSocket must be used within SocketProvider");
  }
  return context;
}
