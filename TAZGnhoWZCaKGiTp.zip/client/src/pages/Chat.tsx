import { useState, useEffect } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { useSocket } from "@/contexts/SocketContext";
import { trpc } from "@/lib/trpc";
import ConversationSidebar from "@/components/ConversationSidebar";
import ChatThread from "@/components/ChatThread";
import UserProfile from "@/components/UserProfile";
import { Loader2, User } from "lucide-react";

export default function Chat() {
  const { user, loading: authLoading } = useAuth();
  const { connected } = useSocket();
  const [selectedConversationId, setSelectedConversationId] = useState<
    number | null
  >(null);
  const [showProfile, setShowProfile] = useState(false);

  const { data: conversations, isLoading: conversationsLoading } =
    trpc.conversation.list.useQuery(undefined, {
      enabled: !!user,
    });

  useEffect(() => {
    if (conversations && conversations.length > 0 && !selectedConversationId) {
      setSelectedConversationId(conversations[0].id);
    }
  }, [conversations, selectedConversationId]);

  if (authLoading) {
    return (
      <div className="flex items-center justify-center h-screen bg-background">
        <div className="flex flex-col items-center gap-4">
          <Loader2 className="w-8 h-8 animate-spin text-neon-pink" />
          <p className="text-neon-cyan">Initializing Comet...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return null;
  }

  return (
    <div className="flex h-screen bg-background text-foreground">
      <ConversationSidebar
        conversations={conversations || []}
        selectedConversationId={selectedConversationId}
        onSelectConversation={setSelectedConversationId}
        isLoading={conversationsLoading}
      />

      <div className="flex-1 flex flex-col border-l-2 border-neon-cyan">
        <div className="flex items-center justify-between p-4 border-b-2 border-neon-cyan bg-black bg-opacity-50">
          <h1 className="text-xl font-bold text-neon-cyan">Comet</h1>
          <button
            onClick={() => setShowProfile(true)}
            className="p-2 hover:bg-gray-800 transition-colors rounded-sm border border-neon-cyan"
            title="View Profile"
          >
            <User size={20} className="text-neon-cyan" />
          </button>
        </div>

        {selectedConversationId ? (
          <ChatThread
            conversationId={selectedConversationId}
            currentUser={user}
          />
        ) : (
          <div className="flex-1 flex items-center justify-center">
            <div className="text-center">
              <h2 className="text-2xl text-neon-cyan mb-4">
                Welcome to Comet
              </h2>
              <p className="text-muted-foreground">
                Select a conversation to start messaging
              </p>
            </div>
          </div>
        )}
      </div>

      {!connected && (
        <div className="fixed bottom-4 right-4 px-4 py-2 bg-red-900 border-2 border-red-500 text-red-100 rounded-sm">
          <p className="text-sm">Reconnecting...</p>
        </div>
      )}

      {showProfile && <UserProfile onClose={() => setShowProfile(false)} />}
    </div>
  );
}
