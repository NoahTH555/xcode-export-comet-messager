import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { Button } from "@/components/ui/button";
import { Loader2 } from "lucide-react";
import { useLocation } from "wouter";
import { useEffect } from "react";

export default function Home() {
  const { user, loading, isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();

  // Redirect to chat if authenticated
  useEffect(() => {
    if (isAuthenticated && user) {
      setLocation("/chat");
    }
  }, [isAuthenticated, user, setLocation]);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen bg-background">
        <div className="flex flex-col items-center gap-4">
          <Loader2 className="w-8 h-8 animate-spin text-neon-pink" />
          <p className="text-neon-cyan">Loading Comet...</p>
        </div>
      </div>
    );
  }

  if (isAuthenticated) {
    return null; // Will redirect to /chat
  }

  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col items-center justify-center p-4">
      <div className="max-w-md text-center">
        <h1 className="text-5xl font-bold text-neon-pink mb-4 animate-neon-glow">
          COMET
        </h1>
        <p className="text-xl text-neon-cyan mb-2">Real-Time Messaging</p>
        <p className="text-muted-foreground mb-8">
          Connect with others in real-time. Experience the future of messaging
          with our cyberpunk-inspired platform.
        </p>

        <div className="space-y-4">
          <a href={getLoginUrl()}>
            <Button className="w-full btn-neon py-6 text-lg">
              Enter Comet
            </Button>
          </a>
          <p className="text-xs text-muted-foreground">
            Sign in with your Manus account to get started
          </p>
        </div>

        {/* Features */}
        <div className="mt-12 space-y-4 text-left">
          <div className="p-4 card-neon">
            <p className="font-bold text-neon-cyan mb-1">Direct Messaging</p>
            <p className="text-sm text-muted-foreground">
              Send private messages to other users instantly
            </p>
          </div>
          <div className="p-4 card-neon">
            <p className="font-bold text-neon-cyan mb-1">Group Chats</p>
            <p className="text-sm text-muted-foreground">
              Create and manage group conversations with multiple participants
            </p>
          </div>
          <div className="p-4 card-neon">
            <p className="font-bold text-neon-cyan mb-1">Real-Time Sync</p>
            <p className="text-sm text-muted-foreground">
              See messages, typing indicators, and presence status in real-time
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
